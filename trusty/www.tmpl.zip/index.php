<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?= $_SERVER["HTTP_HOST"] ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="http://<?= $_SERVER["HTTP_HOST"] ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="http://<?= $_SERVER["HTTP_HOST"] ?>/css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body{padding-top:20px;padding-bottom:60px}
    </style>
  </head>
  <body>
    <div class="container">
        <div class="centered text-center">
            <h2><?= $_SERVER["HTTP_HOST"] ?></h2>
            <a class="btn btn-small btn-success" href="mailto:xen1024@outlook.com">Contact now!</a>
        </div>
    </div>
  </body>
</html>
