USE mysql;
TRUNCATE TABLE db;
TRUNCATE TABLE proxies_priv;
DELETE FROM user WHERE Host <> 'localhost';
FLUSH PRIVILEGES;
